
  # Data Management System Mockup

  This is a code bundle for Data Management System Mockup. The original project is available at https://www.figma.com/design/VVLyB9ERKltNO1BzXdA4B4/Data-Management-System-Mockup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  