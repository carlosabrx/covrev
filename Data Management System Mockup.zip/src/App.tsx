import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { Badge } from './components/ui/badge';
import { Copy, Upload, Download, Plus } from 'lucide-react';
import { DealInformationForm } from './components/DealInformationForm';
import { FinancialMetricsForm } from './components/FinancialMetricsForm';
import { DebtCovenantsForm } from './components/DebtCovenantsForm';
import { BasketProvisionsForm } from './components/BasketProvisionsForm';
import { CapacityRestrictionsForm } from './components/CapacityRestrictionsForm';
import { ProtectionScoresForm } from './components/ProtectionScoresForm';
import { StatusCoverageForm } from './components/StatusCoverageForm';
import exampleImage from 'figma:asset/830defb44196b2a1c289e3d9924f23d7d75f2f0f.png';

export default function App() {
  const [activeTab, setActiveTab] = useState('deal-info');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-primary-foreground px-6 py-4 shadow-sm">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-yellow-500 rounded flex items-center justify-center">
                <span className="text-primary font-bold text-sm">CS</span>
              </div>
              <span className="font-medium">CreditSights</span>
            </div>
            <span className="text-primary-foreground/70">European Loans API Feed</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="bg-transparent border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10">
              <Copy className="w-4 h-4 mr-1" />
              Copy
            </Button>
            <Button variant="outline" size="sm" className="bg-transparent border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10">
              <Upload className="w-4 h-4 mr-1" />
              Import
            </Button>
            <Button variant="outline" size="sm" className="bg-transparent border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10">
              <Download className="w-4 h-4 mr-1" />
              Export
            </Button>
            <Button variant="outline" size="sm" className="bg-green-600 border-green-600 text-white hover:bg-green-700">
              <Plus className="w-4 h-4 mr-1" />
              Add More
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Data Categories</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="space-y-1">
                  <button
                    onClick={() => setActiveTab('deal-info')}
                    className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                      activeTab === 'deal-info' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'hover:bg-muted text-muted-foreground'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      Deal Information
                      <Badge variant="secondary" className="ml-2">15</Badge>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab('financial')}
                    className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                      activeTab === 'financial' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'hover:bg-muted text-muted-foreground'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      Financial Metrics
                      <Badge variant="secondary" className="ml-2">24</Badge>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab('covenants')}
                    className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                      activeTab === 'covenants' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'hover:bg-muted text-muted-foreground'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      Debt Covenants
                      <Badge variant="secondary" className="ml-2">35</Badge>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab('baskets')}
                    className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                      activeTab === 'baskets' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'hover:bg-muted text-muted-foreground'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      Basket Provisions
                      <Badge variant="secondary" className="ml-2">28</Badge>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab('capacity')}
                    className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                      activeTab === 'capacity' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'hover:bg-muted text-muted-foreground'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      Capacity & Restrictions
                      <Badge variant="secondary" className="ml-2">18</Badge>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab('protection')}
                    className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                      activeTab === 'protection' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'hover:bg-muted text-muted-foreground'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      Protection Scores
                      <Badge variant="secondary" className="ml-2">42</Badge>
                    </div>
                  </button>
                  <button
                    onClick={() => setActiveTab('status')}
                    className={`w-full text-left px-4 py-3 text-sm transition-colors ${
                      activeTab === 'status' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'hover:bg-muted text-muted-foreground'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      Status & Coverage
                      <Badge variant="secondary" className="ml-2">12</Badge>
                    </div>
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Form Area */}
          <div className="lg:col-span-3">
            <div className="space-y-6">
              {activeTab === 'deal-info' && <DealInformationForm />}
              {activeTab === 'financial' && <FinancialMetricsForm />}
              {activeTab === 'covenants' && <DebtCovenantsForm />}
              {activeTab === 'baskets' && <BasketProvisionsForm />}
              {activeTab === 'capacity' && <CapacityRestrictionsForm />}
              {activeTab === 'protection' && <ProtectionScoresForm />}
              {activeTab === 'status' && <StatusCoverageForm />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}