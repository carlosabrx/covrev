import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';

export function CapacityRestrictionsForm() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Non-Ratio Capacity</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Incremental General Purpose Debt Capacity</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="non-ratio-gen-enter">Enter Number</Label>
                <Input id="non-ratio-gen-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-gen-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-gen-capacity">Capacity</Label>
                <Input id="non-ratio-gen-capacity" placeholder="Enter capacity details" />
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="non-ratio-gen-turns">Turns</Label>
              <Input id="non-ratio-gen-turns" type="number" step="0.1" placeholder="Enter turns" className="mt-2" />
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Incremental First Lien Debt Capacity</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="non-ratio-first-enter">Enter Number</Label>
                <Input id="non-ratio-first-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-first-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-first-capacity">Capacity</Label>
                <Input id="non-ratio-first-capacity" placeholder="Enter capacity details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Unrestricted Sub Investment Capacity</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="non-ratio-sub-enter">Enter Number</Label>
                <Input id="non-ratio-sub-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-sub-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-sub-capacity">Capacity</Label>
                <Input id="non-ratio-sub-capacity" placeholder="Enter capacity details" />
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="non-ratio-sub-turns">Turns</Label>
              <Input id="non-ratio-sub-turns" type="number" step="0.1" placeholder="Enter turns" className="mt-2" />
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Dividend Stock Repurchase Capacity</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="non-ratio-div-enter">Enter Number</Label>
                <Input id="non-ratio-div-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-div-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-div-capacity">Capacity</Label>
                <Input id="non-ratio-div-capacity" placeholder="Enter capacity details" />
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="non-ratio-div-turns">Turns</Label>
              <Input id="non-ratio-div-turns" type="number" step="0.1" placeholder="Enter turns" className="mt-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Minimum Non-Ratio Debt Capacity</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">PYP Debt</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="min-pyp-enter">Enter Number</Label>
                <Input id="min-pyp-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="min-pyp-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="min-pyp-debt">PYP Debt</Label>
                <Input id="min-pyp-debt" placeholder="Enter debt details" />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div className="flex items-center space-x-2">
                <Switch id="min-pyp-incremental-gen" />
                <Label htmlFor="min-pyp-incremental-gen">Incremental General Purpose Debt</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="min-pyp-incremental-parity" />
                <Label htmlFor="min-pyp-incremental-parity">Incremental Parity Lien Debt</Label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Fixed Plus Incurrence Capacity</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Incremental General Purpose Debt Capacity</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fixed-gen-enter">Enter Number</Label>
                <Input id="fixed-gen-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fixed-gen-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="fixed-gen-capacity">Capacity</Label>
                <Input id="fixed-gen-capacity" placeholder="Enter capacity details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Incremental First Lien Debt Capacity</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fixed-first-enter">Enter Number</Label>
                <Input id="fixed-first-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fixed-first-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="fixed-first-capacity">Capacity</Label>
                <Input id="fixed-first-capacity" placeholder="Enter capacity details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Dividend Stock Repurchase Capacity</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fixed-div-enter">Enter Number</Label>
                <Input id="fixed-div-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fixed-div-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="fixed-div-capacity">Capacity</Label>
                <Input id="fixed-div-capacity" placeholder="Enter capacity details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Unrestricted Sub Investment Capacity</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fixed-sub-enter">Enter Number</Label>
                <Input id="fixed-sub-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fixed-sub-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="fixed-sub-capacity">Capacity</Label>
                <Input id="fixed-sub-capacity" placeholder="Enter capacity details" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>ESG & Assignment Provisions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch id="esg-sustainability" />
            <Label htmlFor="esg-sustainability">ESG Sustainability Ratchet Y/N</Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch id="cross-default" />
            <Label htmlFor="cross-default">EoD Cross Default To Fin Cov</Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch id="cross-acceleration" />
            <Label htmlFor="cross-acceleration">EoD Cross Acceleration To Fin Cov</Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch id="transfer-consent" />
            <Label htmlFor="transfer-consent">Assignments Buybacks Transfer Consent Fall Away All EoDs</Label>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Switch id="deemed-consent" />
              <Label htmlFor="deemed-consent">Deemed Consent Y/N</Label>
            </div>
            <div className="space-y-2">
              <Label htmlFor="deemed-consent-period">Deemed Consent Period</Label>
              <Input id="deemed-consent-period" type="number" placeholder="Enter period in days" />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline">Save Draft</Button>
        <Button>Save & Continue</Button>
      </div>
    </div>
  );
}