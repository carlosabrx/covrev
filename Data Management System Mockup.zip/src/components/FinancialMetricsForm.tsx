import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Separator } from './ui/separator';

export function FinancialMetricsForm() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Opening EBITDA</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="ebitda-currency">Opening LTM EBITDA Currency</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="eur">EUR</SelectItem>
                  <SelectItem value="usd">USD</SelectItem>
                  <SelectItem value="gbp">GBP</SelectItem>
                  <SelectItem value="chf">CHF</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ebitda-amount">Opening LTM EBITDA</Label>
              <Input id="ebitda-amount" type="number" placeholder="Enter EBITDA amount" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Opening Leverage Ratios</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Gross First Lien Leverage</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="gross-first-lien-enter">Opening Gross First Lien Leverage (Enter Number)</Label>
                <Input id="gross-first-lien-enter" type="number" step="0.01" placeholder="Enter ratio" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gross-first-lien">Opening Gross First Lien Leverage</Label>
                <Input id="gross-first-lien" placeholder="Enter leverage details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Gross Secured Leverage</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="gross-secured-enter">Opening Gross Secured Leverage (Enter Number)</Label>
                <Input id="gross-secured-enter" type="number" step="0.01" placeholder="Enter ratio" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gross-secured">Opening Gross Secured Leverage</Label>
                <Input id="gross-secured" placeholder="Enter leverage details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Gross Total Leverage</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="gross-total-enter">Opening Gross Total Leverage (Enter Number)</Label>
                <Input id="gross-total-enter" type="number" step="0.01" placeholder="Enter ratio" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gross-total">Opening Gross Total Leverage</Label>
                <Input id="gross-total" placeholder="Enter leverage details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Net First Lien Leverage</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="net-first-lien-enter">Opening Net First Lien Leverage (Enter Number)</Label>
                <Input id="net-first-lien-enter" type="number" step="0.01" placeholder="Enter ratio" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="net-first-lien">Opening Net First Lien Leverage</Label>
                <Input id="net-first-lien" placeholder="Enter leverage details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Net Secured Leverage</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="net-secured-enter">Opening Net Secured Leverage (Enter Number)</Label>
                <Input id="net-secured-enter" type="number" step="0.01" placeholder="Enter ratio" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="net-secured">Opening Net Secured Leverage</Label>
                <Input id="net-secured" placeholder="Enter leverage details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Net Total Leverage</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="net-total-enter">Opening Net Total Leverage (Enter Number)</Label>
                <Input id="net-total-enter" type="number" step="0.01" placeholder="Enter ratio" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="net-total">Opening Net Total Leverage</Label>
                <Input id="net-total" placeholder="Enter leverage details" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Coverage Ratios</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Interest Coverage Ratio</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="interest-coverage-enter">Opening Interest Coverage Ratio (Enter Number)</Label>
                <Input id="interest-coverage-enter" type="number" step="0.01" placeholder="Enter ratio" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="interest-coverage">Opening Interest Coverage Ratio</Label>
                <Input id="interest-coverage" placeholder="Enter coverage details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Fixed Charge Coverage Ratio</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fixed-charge-enter">Opening Fixed Charge Coverage Ratio (Enter Number)</Label>
                <Input id="fixed-charge-enter" type="number" step="0.01" placeholder="Enter ratio" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fixed-charge">Opening Fixed Charge Coverage Ratio</Label>
                <Input id="fixed-charge" placeholder="Enter coverage details" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline">Save Draft</Button>
        <Button>Save & Continue</Button>
      </div>
    </div>
  );
}