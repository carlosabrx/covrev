import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';
import { Textarea } from './ui/textarea';

export function DebtCovenantsForm() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Debt Covenant Accordion</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Freebie Capped Amount</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="freebie-capped-enter">Freebie Capped Amount (Enter Number)</Label>
                <Input id="freebie-capped-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="freebie-capped-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="freebie-capped-amount">Freebie Capped Amount</Label>
                <Input id="freebie-capped-amount" placeholder="Enter details" />
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Freebie Grower</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="freebie-grower-percent">Freebie Grower Percent</Label>
                <Input id="freebie-grower-percent" type="number" step="0.01" placeholder="Enter percentage" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="freebie-grower-type">Freebie Grower Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="annual">Annual</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Ratio Details</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ratio-enter">Ratio (Enter Number)</Label>
                <Input id="ratio-enter" type="number" step="0.01" placeholder="Enter ratio" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ratio-debt-type">Debt Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="first-lien">First Lien</SelectItem>
                    <SelectItem value="secured">Secured</SelectItem>
                    <SelectItem value="total">Total</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="ratio-level">Ratio Level</Label>
                <Input id="ratio-level" placeholder="Enter level" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ratio-type">Ratio Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="incurrence">Incurrence</SelectItem>
                    <SelectItem value="springing">Springing</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>MFN Provisions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="mfn-basis-points">MFN Basis Points</Label>
              <Input id="mfn-basis-points" type="number" placeholder="Enter basis points" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mfn-sunset">MFN Sunset</Label>
              <Input id="mfn-sunset" type="date" />
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">MFN Carveouts</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="maturity-carveout" />
                <Label htmlFor="maturity-carveout">Maturity Carveout Y/N</Label>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="maturity-carveout-years">Maturity Carveout Years After</Label>
                  <Input id="maturity-carveout-years" type="number" placeholder="Enter years" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mfn-carveouts">MFN Carveouts</Label>
                  <Textarea id="mfn-carveouts" placeholder="Enter carveout details" className="min-h-[80px]" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="mfn-carveouts-capped-enter">MFN Carveouts Capped Amount (Enter Number)</Label>
                  <Input id="mfn-carveouts-capped-enter" type="number" placeholder="Enter amount" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mfn-carveouts-currency">Currency</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="eur">EUR</SelectItem>
                      <SelectItem value="usd">USD</SelectItem>
                      <SelectItem value="gbp">GBP</SelectItem>
                      <SelectItem value="chf">CHF</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mfn-carveouts-amount">MFN Carveouts Capped Amount</Label>
                  <Input id="mfn-carveouts-amount" placeholder="Enter details" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="mfn-grower-enter">MFN Carveouts Grower (Enter Number)</Label>
                  <Input id="mfn-grower-enter" type="number" placeholder="Enter number" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mfn-grower-percent">Grower Percent</Label>
                  <Input id="mfn-grower-percent" type="number" step="0.01" placeholder="Enter percentage" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mfn-grower-type">Grower Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="annual">Annual</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Synergy Cost Saving</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="syn-capped-enter">Syn Cost Saving Capped Amount (Enter Number)</Label>
              <Input id="syn-capped-enter" type="number" placeholder="Enter amount" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="syn-grower-enter">Grower (Enter Number)</Label>
              <Input id="syn-grower-enter" type="number" placeholder="Enter number" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="syn-grower-percent">Grower Percent</Label>
              <Input id="syn-grower-percent" type="number" step="0.01" placeholder="Enter percentage" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="syn-grower-type">Grower Type</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="annual">Annual</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="syn-applies">Applies Before/After Giving Effect To Addbacks</Label>
            <Select>
              <SelectTrigger>
                <SelectValue placeholder="Select timing" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="before">Before</SelectItem>
                <SelectItem value="after">After</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Financial Maintenance Covenants</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch id="cov-lite" />
            <Label htmlFor="cov-lite">Cov-lite</Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch id="maintenance-covenant" />
            <Label htmlFor="maintenance-covenant">EoD Maintenance Covenant Y/N</Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Switch id="springing-trigger" />
            <Label htmlFor="springing-trigger">Springing Trigger Y/N</Label>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="rev-utilization">Rev Utilization Trigger</Label>
              <Input id="rev-utilization" type="number" step="0.01" placeholder="Enter trigger percentage" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="apply-rev-tla">Apply To Rev Or TLA Y/N</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select option" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">Yes</SelectItem>
                  <SelectItem value="no">No</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline">Save Draft</Button>
        <Button>Save & Continue</Button>
      </div>
    </div>
  );
}