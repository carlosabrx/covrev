import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';

export function ProtectionScoresForm() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Composite Scores</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="composite-score">Composite Score</Label>
              <Input id="composite-score" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="collateral-protection">Collateral Protection</Label>
              <Input id="collateral-protection" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="default-protection">Default Protection</Label>
              <Input id="default-protection" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lenders-repricing">Lenders Repricing Optionality</Label>
              <Input id="lenders-repricing" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="liquidity-protection">Liquidity Protection</Label>
              <Input id="liquidity-protection" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reporting-protection">Reporting Protection</Label>
              <Input id="reporting-protection" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="jdp-protection">JDP Protection</Label>
              <Input id="jdp-protection" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="value-leakage">Value Leakage</Label>
              <Input id="value-leakage" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="adjusted-ebitda">Adjusted EBITDA</Label>
              <Input id="adjusted-ebitda" type="number" step="0.1" placeholder="Enter score" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Detailed Protection Metrics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="builder-basket">Builder Basket</Label>
              <Input id="builder-basket" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="amendments">Amendments</Label>
              <Input id="amendments" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mandatory-prepayments">Mandatory Prepayments</Label>
              <Input id="mandatory-prepayments" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="transfer-provisions">Transfer Provisions</Label>
              <Input id="transfer-provisions" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="structural-subordination">Structural Subordination</Label>
              <Input id="structural-subordination" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="reporting">Reporting</Label>
              <Input id="reporting" type="number" step="0.1" placeholder="Enter score" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="junior-debt-prepayments">Junior Debt Prepayments</Label>
              <Input id="junior-debt-prepayments" type="number" step="0.1" placeholder="Enter score" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Special Provisions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-medium text-muted-foreground">Standard Provisions</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="act-reasonably-1">Act Reasonably</Label>
                  <Switch id="act-reasonably-1" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="distressed-fallaway-1">Distressed Fallaway Updated</Label>
                  <Switch id="distressed-fallaway-1" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="white-list-1">White List</Label>
                  <Switch id="white-list-1" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="pick-your-poison">Pick Your Poison</Label>
                  <Switch id="pick-your-poison" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="chewy-phantom-1">Chewy Phantom Guarantee</Label>
                  <Switch id="chewy-phantom-1" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="jcrew-blocker">J.Crew Blocker</Label>
                  <Switch id="jcrew-blocker" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-muted-foreground">Additional Provisions</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="uncap-inter-comp">Uncap Inter Comp Invest</Label>
                  <Switch id="uncap-inter-comp" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="portability">Portability</Label>
                  <Switch id="portability" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="highest-watermark-1">Highest Watermark</Label>
                  <Switch id="highest-watermark-1" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="revolver-exclusion-1">Revolver Exclusion</Label>
                  <Switch id="revolver-exclusion-1" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="auto-reclassify-1">Auto Reclassify</Label>
                  <Switch id="auto-reclassify-1" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="scope-jdp-covenant-1">Scope JDP Covenant</Label>
                  <Switch id="scope-jdp-covenant-1" />
                </div>
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h4 className="font-medium text-muted-foreground">Asset Sale & Reporting</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="asset-sale-sweep">Asset Sale Sweep Percentage</Label>
                <Input id="asset-sale-sweep" type="number" step="0.01" placeholder="Enter percentage" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="test-date">Test Date</Label>
                <Input id="test-date" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="reporting-periods">Reporting Periods</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="semi-annual">Semi-Annual</SelectItem>
                    <SelectItem value="annual">Annual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h4 className="font-medium text-muted-foregroup">Capacity Turns</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="non-ratio-gen-turns">Non-Ratio Incremental Gen Purpose Debt Capacity (Turns)</Label>
                <Input id="non-ratio-gen-turns" type="number" step="0.1" placeholder="Enter turns" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-div-turns">Non-Ratio Dividend Stock Repurchase Capacity (Turns)</Label>
                <Input id="non-ratio-div-turns" type="number" step="0.1" placeholder="Enter turns" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="non-ratio-sub-turns">Non-Ratio Unrestricted Sub Inv Capacity (Turns)</Label>
                <Input id="non-ratio-sub-turns" type="number" step="0.1" placeholder="Enter turns" />
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h4 className="font-medium text-muted-foreground">Important Dates</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="mfn-expired">MFN Expired Date</Label>
                <Input id="mfn-expired" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="document-date">Document Date (Backfilled)</Label>
                <Input id="document-date" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="research-date">Research Date (Backfilled)</Label>
                <Input id="research-date" type="date" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline">Save Draft</Button>
        <Button>Save & Continue</Button>
      </div>
    </div>
  );
}