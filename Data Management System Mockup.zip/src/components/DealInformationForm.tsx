import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';

export function DealInformationForm() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Basic Deal Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="origin">Origin</Label>
              <Input id="origin" placeholder="Enter origin" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="borrower">Borrower</Label>
              <Input id="borrower" placeholder="Enter borrower name" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sector">Sector</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select sector" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                  <SelectItem value="financial">Financial Services</SelectItem>
                  <SelectItem value="retail">Retail</SelectItem>
                  <SelectItem value="manufacturing">Manufacturing</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="transaction">Transaction</Label>
              <Input id="transaction" placeholder="Enter transaction type" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ownership">Ownership</Label>
              <Input id="ownership" placeholder="Enter ownership structure" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="corp-rating">Corp Rating</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select rating" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="aaa">AAA</SelectItem>
                  <SelectItem value="aa">AA</SelectItem>
                  <SelectItem value="a">A</SelectItem>
                  <SelectItem value="bbb">BBB</SelectItem>
                  <SelectItem value="bb">BB</SelectItem>
                  <SelectItem value="b">B</SelectItem>
                  <SelectItem value="ccc">CCC</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="facility-rating">Facility Rating</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select rating" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="aaa">AAA</SelectItem>
                  <SelectItem value="aa">AA</SelectItem>
                  <SelectItem value="a">A</SelectItem>
                  <SelectItem value="bbb">BBB</SelectItem>
                  <SelectItem value="bb">BB</SelectItem>
                  <SelectItem value="b">B</SelectItem>
                  <SelectItem value="ccc">CCC</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="deal-status">Deal Status</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="mandated-arrangers">Mandated Lead Arrangers</Label>
              <Textarea 
                id="mandated-arrangers" 
                placeholder="Enter mandated lead arrangers"
                className="min-h-[80px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tranche-name">Tranche Name</Label>
              <Input id="tranche-name" placeholder="Enter tranche name" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Facility Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tranche-identifier">Tranche Name (Identifier for Add-ons)</Label>
              <Input id="tranche-identifier" placeholder="Enter identifier" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="current-size">Current Size</Label>
              <Input id="current-size" type="number" placeholder="Enter size" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="eur">EUR</SelectItem>
                  <SelectItem value="usd">USD</SelectItem>
                  <SelectItem value="gbp">GBP</SelectItem>
                  <SelectItem value="chf">CHF</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="current-term">Current Term</Label>
              <Input id="current-term" placeholder="Enter term" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="maturity-date">Current Maturity Date</Label>
              <Input id="maturity-date" type="date" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="current-calls">Current Calls</Label>
              <Input id="current-calls" placeholder="Enter calls" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="current-spread">Current Spread (bps)</Label>
              <Input id="current-spread" type="number" placeholder="Enter spread" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="current-floor">Current Floor (%)</Label>
              <Input id="current-floor" type="number" step="0.01" placeholder="Enter floor" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cleared-date">Cleared Date</Label>
              <Input id="cleared-date" type="date" />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline">Save Draft</Button>
        <Button>Save & Continue</Button>
      </div>
    </div>
  );
}