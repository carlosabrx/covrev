import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';

export function StatusCoverageForm() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Status Fields</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="terms-status">Terms Status</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="complete">Complete</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-review">In Review</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="lxid-status">LXID Status</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="complete">Complete</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-review">In Review</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="record-priority">Record Priority</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Coverage Indicators</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="space-y-4">
              <h4 className="font-medium text-muted-foreground">Primary Coverage</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="lfi-coverage">LFI Coverage</Label>
                    <Badge variant="secondary" className="text-xs">Key</Badge>
                  </div>
                  <Switch id="lfi-coverage" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="cr-coverage">CR Coverage</Label>
                    <Badge variant="secondary" className="text-xs">Key</Badge>
                  </div>
                  <Switch id="cr-coverage" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="scoring-coverage">Scoring Coverage</Label>
                  <Switch id="scoring-coverage" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-muted-foreground">Secondary Coverage</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="maintenance-cov-lite">Maintenance Cov-lite CLO</Label>
                  <Switch id="maintenance-cov-lite" />
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <Label htmlFor="clo-coverage">CLO Coverage</Label>
                  <Switch id="clo-coverage" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium text-muted-foreground">Coverage Summary</h4>
              <div className="p-4 bg-muted rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Total Coverage Items:</span>
                  <Badge variant="outline">5</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Active Coverage:</span>
                  <Badge variant="default">3</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Coverage Percentage:</span>
                  <Badge variant="secondary">60%</Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Covenant Coverage Baskets</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Dividends Coverage General Basket</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="space-y-2">
                <Label htmlFor="div-cov-capped-enter">Capped Amount (Enter Number)</Label>
                <Input id="div-cov-capped-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="div-cov-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="div-cov-amount">Capped Amount</Label>
                <Input id="div-cov-amount" placeholder="Enter details" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="div-cov-grower-enter">Grower (Enter Number)</Label>
                <Input id="div-cov-grower-enter" type="number" placeholder="Enter number" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="div-cov-grower-percent">Grower Percent</Label>
                <Input id="div-cov-grower-percent" type="number" step="0.01" placeholder="Enter percentage" />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="div-cov-grower-type">Grower Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="annual">Annual</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="div-cov-annual-refresh" />
                <Label htmlFor="div-cov-annual-refresh">Annual Refresh</Label>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foregroup">JDP General Basket</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="space-y-2">
                <Label htmlFor="jdp-capped-enter">Capped Amount (Enter Number)</Label>
                <Input id="jdp-capped-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="jdp-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="jdp-amount">Capped Amount</Label>
                <Input id="jdp-amount" placeholder="Enter details" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="jdp-grower-enter">Grower (Enter Number)</Label>
                <Input id="jdp-grower-enter" type="number" placeholder="Enter number" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="jdp-grower-percent">Grower Percent</Label>
                <Input id="jdp-grower-percent" type="number" step="0.01" placeholder="Enter percentage" />
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="jdp-grower-type">Grower Type</Label>
              <Select>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="annual">Annual</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foregroup">Investments Coverage</h4>
            <div className="space-y-4">
              <div>
                <h5 className="text-sm font-medium mb-3 text-muted-foreground">Ratio Carveout</h5>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="inv-ratio-carveout-enter">Ratio (Enter Number)</Label>
                    <Input id="inv-ratio-carveout-enter" type="number" step="0.01" placeholder="Enter ratio" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inv-ratio-carveout-level">Ratio Level</Label>
                    <Input id="inv-ratio-carveout-level" placeholder="Enter level" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inv-ratio-carveout-name">Ratio Name</Label>
                    <Input id="inv-ratio-carveout-name" placeholder="Enter ratio name" />
                  </div>
                </div>
              </div>

              <div>
                <h5 className="text-sm font-medium mb-3 text-muted-foreground">General Basket</h5>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="inv-gen-capped-enter">Capped Amount (Enter Number)</Label>
                    <Input id="inv-gen-capped-enter" type="number" placeholder="Enter amount" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inv-gen-currency">Currency</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="eur">EUR</SelectItem>
                        <SelectItem value="usd">USD</SelectItem>
                        <SelectItem value="gbp">GBP</SelectItem>
                        <SelectItem value="chf">CHF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inv-gen-amount">Capped Amount</Label>
                    <Input id="inv-gen-amount" placeholder="Enter details" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="inv-gen-grower-percent">Grower Percent</Label>
                    <Input id="inv-gen-grower-percent" type="number" step="0.01" placeholder="Enter percentage" />
                  </div>
                </div>
                <div className="mt-4">
                  <Label htmlFor="inv-gen-grower-type">Grower Type</Label>
                  <Select>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="annual">Annual</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <div className="flex gap-2">
          <Button variant="outline">Reset Form</Button>
          <Button variant="outline">Load Template</Button>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">Save Draft</Button>
          <Button>Complete Entry</Button>
        </div>
      </div>
    </div>
  );
}