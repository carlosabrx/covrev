import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Switch } from './ui/switch';

export function BasketProvisionsForm() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Debt Covenant General Basket</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="debt-general-capped-enter">General Basket Capped Amount (Enter Number)</Label>
              <Input id="debt-general-capped-enter" type="number" placeholder="Enter amount" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="debt-general-currency">Currency</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="eur">EUR</SelectItem>
                  <SelectItem value="usd">USD</SelectItem>
                  <SelectItem value="gbp">GBP</SelectItem>
                  <SelectItem value="chf">CHF</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="debt-general-amount">General Basket Capped Amount</Label>
              <Input id="debt-general-amount" placeholder="Enter details" />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="debt-general-grower-enter">Grower (Enter Number)</Label>
              <Input id="debt-general-grower-enter" type="number" placeholder="Enter number" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="debt-general-grower-percent">Grower Percent</Label>
              <Input id="debt-general-grower-percent" type="number" step="0.01" placeholder="Enter percentage" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="debt-general-grower-type">Grower Type</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="annual">Annual</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Builder Basket</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center space-x-2">
            <Switch id="builder-basket-exists" />
            <Label htmlFor="builder-basket-exists">Builder Basket Exists</Label>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Dividends</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="builder-dividends" />
                <Label htmlFor="builder-dividends">Can Use For Dividends</Label>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="builder-div-ratio-condition">Ratio Conditionality</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="pro-forma">Pro Forma</SelectItem>
                      <SelectItem value="actual">Actual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="builder-div-ratio-level">Ratio Level</Label>
                  <Input id="builder-div-ratio-level" type="number" step="0.01" placeholder="Enter level" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="builder-div-ratio-name">Ratio Name</Label>
                  <Input id="builder-div-ratio-name" placeholder="Enter ratio name" />
                </div>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Investments</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="builder-investments" />
                <Label htmlFor="builder-investments">Can Use For Investments</Label>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="builder-inv-ratio-condition">Ratio Conditionality</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="pro-forma">Pro Forma</SelectItem>
                      <SelectItem value="actual">Actual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="builder-inv-ratio-level">Ratio Level</Label>
                  <Input id="builder-inv-ratio-level" type="number" step="0.01" placeholder="Enter level" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="builder-inv-ratio-name">Ratio Name</Label>
                  <Input id="builder-inv-ratio-name" placeholder="Enter ratio name" />
                </div>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Builder Basket Starter</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="space-y-2">
                <Label htmlFor="builder-starter-enter">Starter (Enter Number)</Label>
                <Input id="builder-starter-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="builder-starter-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="builder-starter-amount">Starter Amount</Label>
                <Input id="builder-starter-amount" placeholder="Enter details" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="builder-starter-grower-percent">Starter Grower Percent</Label>
                <Input id="builder-starter-grower-percent" type="number" step="0.01" placeholder="Enter percentage" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="builder-starter-grower-type">Starter Grower Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="annual">Annual</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Available Amount EU</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center space-x-2">
            <Switch id="available-amount-exists" />
            <Label htmlFor="available-amount-exists">Available Amount EU Exists</Label>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Dividends</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="available-dividends" />
                <Label htmlFor="available-dividends">Can Use For Dividends</Label>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="available-div-ratio-condition">Fully Funded Ratio Conditionality</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="pro-forma">Pro Forma</SelectItem>
                      <SelectItem value="actual">Actual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="available-div-ratio-level">Fully Funded Ratio Level</Label>
                  <Input id="available-div-ratio-level" type="number" step="0.01" placeholder="Enter level" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="available-div-ratio-name">Fully Funded Ratio Name</Label>
                  <Input id="available-div-ratio-name" placeholder="Enter ratio name" />
                </div>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Investments</h4>
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch id="available-investments" />
                <Label htmlFor="available-investments">Can Use For Investments</Label>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="available-inv-ratio-condition">Fully Funded Ratio Conditionality</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="pro-forma">Pro Forma</SelectItem>
                      <SelectItem value="actual">Actual</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="available-inv-ratio-level">Fully Funded Ratio Level</Label>
                  <Input id="available-inv-ratio-level" type="number" step="0.01" placeholder="Enter level" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="available-inv-ratio-name">Fully Funded Ratio Name</Label>
                  <Input id="available-inv-ratio-name" placeholder="Enter ratio name" />
                </div>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h4 className="font-medium mb-4 text-muted-foreground">Available Amount EU Starter</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="space-y-2">
                <Label htmlFor="available-starter-enter">Starter (Enter Number)</Label>
                <Input id="available-starter-enter" type="number" placeholder="Enter amount" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="available-starter-currency">Currency</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eur">EUR</SelectItem>
                    <SelectItem value="usd">USD</SelectItem>
                    <SelectItem value="gbp">GBP</SelectItem>
                    <SelectItem value="chf">CHF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="available-starter-amount">Starter Amount</Label>
                <Input id="available-starter-amount" placeholder="Enter details" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="available-starter-grower-percent">Starter Grower Percent</Label>
                <Input id="available-starter-grower-percent" type="number" step="0.01" placeholder="Enter percentage" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="available-starter-grower-type">Starter Grower Type</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="annual">Annual</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline">Save Draft</Button>
        <Button>Save & Continue</Button>
      </div>
    </div>
  );
}